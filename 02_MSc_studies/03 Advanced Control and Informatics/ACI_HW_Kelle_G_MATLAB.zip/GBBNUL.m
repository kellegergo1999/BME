%% NEPTUN Code: GBBNUL
%%
clear all
clc
%% Initial data
m = 1.53; 
M = 7.37;
L = 3.05;
g = 9.81;
b = 0.2;
J = 1/3 * m * L^2;
%% -------- TASK 2 -------- %%
% Matrices
M_mx=[J+m*L^2, m*L; m*L, M+m];
C_mx=[0,0;0,b];
K_mx=[-m*g*L,0;0,0];
F=[0;1];

% Placeholders
A = zeros(4,4);
B = zeros(4,1);
C = zeros(4,4);
D = zeros(4,1);

% Calculation
A = [zeros(2), eye(2); -M_mx\K_mx, -M_mx\C_mx];
B = [0; M_mx\F; 0];
C = eye(4);

% Ordering
A([2, 3], :) = A([3, 2], :);
A(:, [2,3]) = A(:, [3,2]);
B([3, 4]) = B([4, 3]);
%%
model = 'Task1';
IO = getlinio(model);
OP = operpoint(model);

% Linearization
SYS = linearize(model,IO,OP);
SYS = xperm(SYS, [3 1 4 2]);

A_lin=SYS.A;
B_lin=SYS.B;
C_lin=SYS.C;
D_lin=SYS.D;

% Difference
Diff_A = A- A_lin;
Diff_B = B- B_lin;
%% RUN THE SIMULATION - Task2.slx
%% Plots
figure;

% Plot phi_t2
plot(out.phi_t2_analytic, 'LineWidth', 1.5, 'Color', 'b', 'LineStyle', '-.');
hold on;
plot(out.phi_t2_automatic, 'LineWidth', 1.5, 'Color', 'r', 'LineStyle', '--');

% Plot phi_t1
plot(out.phi_t1, 'LineWidth', 1, 'Color', 'g');

% Plot x_t2
plot(out.x_t2_analytic, 'LineWidth', 1.5, 'Color', 'b', 'LineStyle', '-.');
plot(out.x_t2_automatic, 'LineWidth', 1.5, 'Color', 'r', 'LineStyle', '--');

% Plot x_t1
plot(out.x_t1, 'LineWidth', 1, 'Color', 'k');

legend('phi_{t2} (Analytic lin.)', 'phi_{t2} (Automatic lin.)', 'phi_{t1}', 'x_{t2} (Analytic lin.)', 'x_{t2} (Automatic lin.)', 'x_t1');

xlabel('t [s]');
ylabel('Amplitude');
%title('Comparison of Analytic and Automatic Linearization Results With The Nonlinear Solution');

hold off;
%% -------- TASK 1 -------- %%

% Data
phi_t1 = out.phi_t1;
x_t1 = out.x_t1;
time = out.tout;

% Create a figure
figure(1);

% Subplot for phi
subplot(1, 2, 1);
plot(phi_t1, 'LineWidth', 2);
title('', 'Interpreter', 'latex');
xlabel('t [s]');
ylabel('$\phi$ [ra]', 'Interpreter', 'latex');
grid on;

% Subplot for x
subplot(1, 2, 2);
plot(x_t1, 'LineWidth', 2);
title('', 'Interpreter', 'latex');
xlabel('t [s]');
ylabel('$x$ [m]', 'Interpreter', 'latex');
grid on;

% Adjust the layout
sgtitle('System Response', 'Interpreter', 'latex');

%% -------- TASK 3 -------- %%

[omega_n, damping_factors, poles] = damp(SYS)
time_c = 1./(omega_n.*damping_factors)
figure(2);
pzmap(SYS)
title('Pole-zero map for the linearized model');

% Create a table of output
data = table(omega_n, poles, damping_factors, time_c, 'VariableNames', {'Omega_n', 'Poles', 'Damping_Factor', 'Time_Constants'});
disp(data);

%% -------- TASK 4 -------- %%

% Controlability
Crtb = ctrb(A_lin,B_lin); 
rCrtb = rank(Crtb);
controllability = length(A_lin)-rCrtb;

% Obervability
Obsv = obsv(A_lin,C_lin); 
rObsv = rank(Obsv);
obervability = length(A_lin)-rObsv;

% Display solution
if controllability == 0
    disp('Controllable!');
    disp('---');
else
    disp('NOT controllable!');
    disp('---');
end

if obervability == 0
    disp('Observable!');
    disp('---');
else
    disp('NOT observable!');
    disp('---');
end
%% -------- TASK 5 INCREASING -------- %%

p_init = [-1; -1.1; -1.2; -1.3];
K_n_values = zeros(5, 4);

% Initial conditions
x0 = 1.1;
dx0 = 0.4;
phi0 = 0.1;
dphi0 = 0.3;

dp = [0.25; 0.25; 0.25; 0.25];

% Calculate p values for each iteration
p1 = p_init + dp;
p2 = p1 + dp;
p3 = p2 + dp;
p4 = p3 + dp;
p5 = p4 + dp;

% Calculate K_n values for each iteration
K_n_0 = place(A, B, p_init);
K_n_1 = place(A, B, p1);
K_n_2 = place(A, B, p2);
K_n_3 = place(A, B, p3);
K_n_4 = place(A, B, p4);
K_n_5 = place(A, B, p5);

% Store K_n values in Model Workspace
assignin('base', 'K_n_0_value', K_n_0);
assignin('base', 'K_n_1_value', K_n_1);
assignin('base', 'K_n_2_value', K_n_2);
assignin('base', 'K_n_3_value', K_n_3);
assignin('base', 'K_n_4_value', K_n_4);
assignin('base', 'K_n_5_value', K_n_5);

% Run Simulink models
sim('Task5_v2.slx')


% Pause for 2 seconds
pause(2);

% Create figures for each iteration
figure;
hold on
plot(out.phi_t5_p0.Time, out.phi_t5_p0.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p0.Time, out.phi_t5_p0.Data(:, 2), 'LineWidth', 2)
legend('phi', 'dphi')
title(['State feedback with different poles: ' strjoin(cellstr(num2str(p_init)), ', ')])
saveas(gcf, 'phi_t5_increase_p0.jpg');
figure;
hold on
plot(out.phi_t5_p1.Time, out.phi_t5_p1.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p1.Time, out.phi_t5_p1.Data(:, 2), 'LineWidth', 2)
legend('phi', 'dphi')
title(['State feedback with different poles: ' strjoin(cellstr(num2str(p1)), ', ')])
saveas(gcf, 'phi_t5_increase_p1.jpg');
figure;
hold on
plot(out.phi_t5_p2.Time, out.phi_t5_p2.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p2.Time, out.phi_t5_p2.Data(:, 2), 'LineWidth', 2)
legend('phi', 'dphi')
title(['State feedback with different poles: ' strjoin(cellstr(num2str(p2)), ', ')])
saveas(gcf, 'phi_t5_increase_p2.jpg');
figure;
hold on
plot(out.phi_t5_p3.Time, out.phi_t5_p3.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p3.Time, out.phi_t5_p3.Data(:, 2), 'LineWidth', 2)
legend('phi', 'dphi')
title(['State feedback with different poles: ' strjoin(cellstr(num2str(p3)), ', ')])
saveas(gcf, 'phi_t5_increase_p3.jpg');
figure;
hold on
plot(out.phi_t5_p4.Time, out.phi_t5_p4.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p4.Time, out.phi_t5_p4.Data(:, 2), 'LineWidth', 2)
legend('phi', 'dphi')
title(['State feedback with different poles: ' strjoin(cellstr(num2str(p4)), ', ')])
saveas(gcf, 'phi_t5_increase_p4.jpg');
figure;
hold on
plot(out.phi_t5_p5.Time, out.phi_t5_p5.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p5.Time, out.phi_t5_p5.Data(:, 2), 'LineWidth', 2)
legend('phi', 'dphi')
title(['State feedback with different poles: ' strjoin(cellstr(num2str(p5)), ', ')])
saveas(gcf, 'phi_t5_increase_p5.jpg');
disp('K_n values for each iteration:');
disp([K_n_0; K_n_1; K_n_2; K_n_3; K_n_4; K_n_5]);
%% RUN THE SIMULATION - Task5_v2.slx then rerun the code above to get the right figures
%% Summarizing increase
% Create figures for each iteration

% phi
figure;
hold on
plot(out.phi_t5_p0.Time, out.phi_t5_p0.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p1.Time, out.phi_t5_p1.Data(:, 1), 'LineWidth', 1)
plot(out.phi_t5_p2.Time, out.phi_t5_p2.Data(:, 1), 'LineWidth', 1)
plot(out.phi_t5_p3.Time, out.phi_t5_p3.Data(:, 1), 'LineWidth', 1)
plot(out.phi_t5_p4.Time, out.phi_t5_p4.Data(:, 1), 'LineWidth', 1)
plot(out.phi_t5_p5.Time, out.phi_t5_p5.Data(:, 1), 'LineWidth', 1)
legend('p0 (initial)','p1', 'p2', 'p3', 'p4', 'p5')
ylabel('\phi [rad]')  
title('Comparison of \phi when pole increasing')

saveas(gcf, 'Comparison_phi_t5_increase.jpg');
saveas(gcf, 'Comparison_phi_t5_increase.pdf');

% x
figure;
hold on
plot(out.x_t5_p0.Time, out.x_t5_p0.Data(:, 1), 'LineWidth', 2)
plot(out.x_t5_p1.Time, out.x_t5_p1.Data(:, 1), 'LineWidth', 1)
plot(out.x_t5_p2.Time, out.x_t5_p2.Data(:, 1), 'LineWidth', 1)
plot(out.x_t5_p3.Time, out.x_t5_p3.Data(:, 1), 'LineWidth', 1)
plot(out.x_t5_p4.Time, out.x_t5_p4.Data(:, 1), 'LineWidth', 1)
plot(out.x_t5_p5.Time, out.x_t5_p5.Data(:, 1), 'LineWidth', 1)
legend('p0 (initial)','p1', 'p2', 'p3', 'p4', 'p5')
title('Comparison of x when pole increasing')
ylabel('x [m]')  % Add ylabel for x variable

saveas(gcf, 'Comparison_x_t5_increase.jpg');
saveas(gcf, 'Comparison_x_t5_increase.pdf');

% u
figure;
hold on
plot(out.u0.Time, out.u0.Data(:, 1), 'LineWidth', 2)
plot(out.u.Time, out.u.Data(:, 1), 'LineWidth', 1)
plot(out.u1.Time, out.u1.Data(:, 1), 'LineWidth', 1)
plot(out.u2.Time, out.u2.Data(:, 1), 'LineWidth', 1)
plot(out.u3.Time, out.u3.Data(:, 1), 'LineWidth', 1)
plot(out.u4.Time, out.u4.Data(:, 1), 'LineWidth', 1)
legend('p0 (initial)','p1', 'p2', 'p3', 'p4', 'p5')
title('Comparison of u when pole increasing')
ylabel('u')  % Add ylabel for x variable

saveas(gcf, 'Comparison_u_t5_increase.jpg');
saveas(gcf, 'Comparison_u_t5_increase.pdf');
%% -------- TASK 5 Decreasing -------- %%

p_init = [-1; -1.1; -1.2; -1.3];
K_n_values = zeros(5, 4);

% Initial conditions
x0 = 1.1;
dx0 = 0.4;
phi0 = 0.1;
dphi0 = 0.3;

dp = [-0.5; -0.5; -0.5; -0.5];

% Calculate p values for each iteration
p1 = p_init + dp;
p2 = p1 + dp;
p3 = p2 + dp;
p4 = p3 + dp;
p5 = p4 + dp;

% Calculate K_n values for each iteration
K_n_0 = place(A, B, p_init);
K_n_1 = place(A, B, p1);
K_n_2 = place(A, B, p2);
K_n_3 = place(A, B, p3);
K_n_4 = place(A, B, p4);
K_n_5 = place(A, B, p5);

% Store K_n values in Model Workspace
assignin('base', 'K_n_0_value', K_n_0);
assignin('base', 'K_n_1_value', K_n_1);
assignin('base', 'K_n_2_value', K_n_2);
assignin('base', 'K_n_3_value', K_n_3);
assignin('base', 'K_n_4_value', K_n_4);
assignin('base', 'K_n_5_value', K_n_5);

% Run Simulink models
sim('Task5_v2.slx')


% Pause for 2 seconds
% pause(2);

% Create figures for each iteration
figure;
hold on
plot(out.phi_t5_p0.Time, out.phi_t5_p0.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p0.Time, out.phi_t5_p0.Data(:, 2), 'LineWidth', 2)
legend('phi', 'dphi')
title(['State feedback with different poles: ' strjoin(cellstr(num2str(p_init)), ', ')])
% saveas(gcf, 'phi_t5_decrease_p0.jpg');
figure;
hold on
plot(out.phi_t5_p1.Time, out.phi_t5_p1.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p1.Time, out.phi_t5_p1.Data(:, 2), 'LineWidth', 2)
legend('phi', 'dphi')
title(['State feedback with different poles: ' strjoin(cellstr(num2str(p1)), ', ')])
% saveas(gcf, 'phi_t5_decrease_p1.jpg');
figure;
hold on
plot(out.phi_t5_p2.Time, out.phi_t5_p2.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p2.Time, out.phi_t5_p2.Data(:, 2), 'LineWidth', 2)
legend('phi', 'dphi')
title(['State feedback with different poles: ' strjoin(cellstr(num2str(p2)), ', ')])
% saveas(gcf, 'phi_t5_decrease_p2.jpg');
figure;
hold on
plot(out.phi_t5_p3.Time, out.phi_t5_p3.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p3.Time, out.phi_t5_p3.Data(:, 2), 'LineWidth', 2)
legend('phi', 'dphi')
title(['State feedback with different poles: ' strjoin(cellstr(num2str(p3)), ', ')])
% saveas(gcf, 'phi_t5_decrease_p3.jpg');
figure;
hold on
plot(out.phi_t5_p4.Time, out.phi_t5_p4.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p4.Time, out.phi_t5_p4.Data(:, 2), 'LineWidth', 2)
legend('phi', 'dphi')
title(['State feedback with different poles: ' strjoin(cellstr(num2str(p4)), ', ')])
% saveas(gcf, 'phi_t5_decrease_p4.jpg');
figure;
hold on
plot(out.phi_t5_p5.Time, out.phi_t5_p5.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p5.Time, out.phi_t5_p5.Data(:, 2), 'LineWidth', 2)
legend('phi', 'dphi')
title(['State feedback with different poles: ' strjoin(cellstr(num2str(p5)), ', ')])
% saveas(gcf, 'phi_t5_decrease_p5.jpg');
disp('K_n values for each iteration:');
disp([K_n_0; K_n_1; K_n_2; K_n_3; K_n_4; K_n_5]);
%% RUN THE SIMULATION - Task5_v2.slx then rerun the code above to get the right figures
%% Summarizing decrease

% Create figures for each iteration

% phi
figure;
hold on
plot(out.phi_t5_p0.Time, out.phi_t5_p0.Data(:, 1), 'LineWidth', 2)
plot(out.phi_t5_p1.Time, out.phi_t5_p1.Data(:, 1), 'LineWidth', 1)
plot(out.phi_t5_p2.Time, out.phi_t5_p2.Data(:, 1), 'LineWidth', 1)
plot(out.phi_t5_p3.Time, out.phi_t5_p3.Data(:, 1), 'LineWidth', 1)
plot(out.phi_t5_p4.Time, out.phi_t5_p4.Data(:, 1), 'LineWidth', 1)
plot(out.phi_t5_p5.Time, out.phi_t5_p5.Data(:, 1), 'LineWidth', 1)
legend('p0 (initial)','p1', 'p2', 'p3', 'p4', 'p5')
ylabel('\phi [rad]')  
title('Comparison of \phi when pole decreasing')

%saveas(gcf, 'Comparison_phi_t5_decrease.jpg');
%saveas(gcf, 'Comparison_phi_t5_decrease.pdf');

% x
figure;
hold on
plot(out.x_t5_p0.Time, out.x_t5_p0.Data(:, 1), 'LineWidth', 2)
plot(out.x_t5_p1.Time, out.x_t5_p1.Data(:, 1), 'LineWidth', 1)
plot(out.x_t5_p2.Time, out.x_t5_p2.Data(:, 1), 'LineWidth', 1)
plot(out.x_t5_p3.Time, out.x_t5_p3.Data(:, 1), 'LineWidth', 1)
plot(out.x_t5_p4.Time, out.x_t5_p4.Data(:, 1), 'LineWidth', 1)
plot(out.x_t5_p5.Time, out.x_t5_p5.Data(:, 1), 'LineWidth', 1)
legend('p0 (initial)','p1', 'p2', 'p3', 'p4', 'p5')
title('Comparison of x when pole decreasing')
ylabel('x [m]')  % Add ylabel for x variable

%saveas(gcf, 'Comparison_x_t5_decrease.jpg');
%saveas(gcf, 'Comparison_x_t5_decrease.pdf');

% u
figure;
hold on
plot(out.u0.Time, out.u0.Data(:, 1), 'LineWidth', 2)
plot(out.u.Time, out.u.Data(:, 1), 'LineWidth', 1)
plot(out.u1.Time, out.u1.Data(:, 1), 'LineWidth', 1)
plot(out.u2.Time, out.u2.Data(:, 1), 'LineWidth', 1)
plot(out.u3.Time, out.u3.Data(:, 1), 'LineWidth', 1)
plot(out.u4.Time, out.u4.Data(:, 1), 'LineWidth', 1)
legend('p0 (initial)','p1', 'p2', 'p3', 'p4', 'p5')
title('Comparison of u when pole decreasing')
ylabel('u')  % Add ylabel for x variable

%saveas(gcf, 'Comparison_u_t5_decrease.jpg');
%saveas(gcf, 'Comparison_u_t5_decrease.pdf');

%% -------- TASK 6 -------- %%
R=1;

% Different Q matrices
Q1 = diag([100,1,10,100]); % Initial
Q2 = diag([100,1,1,1]); % phi
Q3 = diag([1,1,100,1]); % x
Q4 = diag([100,1,100,1]); % phi & x
Q5 = diag([1,100,1,100]); % dphi & dx

% Calculation of K matrices
[K_lqr_1,S_lqr_1,P_lqr_1]=lqr(SYS,Q1,R);
[K_lqr_2,S_lqr_2,P_lqr_2]=lqr(SYS,Q2,R);
[K_lqr_3,S_lqr_3,P_lqr_3]=lqr(SYS,Q3,R);
[K_lqr_4,S_lqr_4,P_lqr_4]=lqr(SYS,Q4,R);
[K_lqr_5,S_lqr_5,P_lqr_5]=lqr(SYS,Q5,R);
%% RUN THE SIMULATION - Task6.slx and go to ploting
%% OR with Different R and same initial Q
R=1;
R2=5;
R3=0.1;
Q1 = diag([100,1,10,100]); % Initial

%Calculation of K matrices
[K_lqr_1,S_lqr_1,P_lqr_1]=lqr(SYS,Q1,R);
[K_lqr_2,S_lqr_2,P_lqr_2]=lqr(SYS,Q1,R2);
[K_lqr_3,S_lqr_3,P_lqr_3]=lqr(SYS,Q1,R3);
%% RUN THE SIMULATION - Task6.slx and go to ploting
%% Plot
figure;
plot(out.phi_t6_1.Time, out.phi_t6_1.Data(:,1),'LineWidth',2); hold on; grid on;
plot(out.phi_t6_2.Time, out.phi_t6_2.Data(:,1),'LineWidth',1);
plot(out.phi_t6_3.Time, out.phi_t6_3.Data(:,1),'LineWidth',1);
legend('R_1 (initial)','R_2','R_3','Location','southeast')
xlabel('t [s]')
ylabel('\phi [rad]')
title('\phi for different weighting schemes (only R)')

figure;
plot(out.x_t6_1.Time, out.x_t6_1.Data(:,1),'LineWidth',2); hold on; grid on;
plot(out.x_t6_2.Time, out.x_t6_2.Data(:,1),'LineWidth',1);
plot(out.x_t6_3.Time, out.x_t6_3.Data(:,1),'LineWidth',1);
legend('R_1 (initial)','R_2','R_3','Location','southeast')
xlabel('t [s]')
ylabel('x [m]')
title('x for different weighting schemes (only R)')

figure;
plot(out.u_t6_1.Time, out.u_t6_1.Data(:,1),'LineWidth',2); hold on; grid on;
plot(out.u_t6_2.Time, out.u_t6_2.Data(:,1),'LineWidth',1);
plot(out.u_t6_3.Time, out.u_t6_3.Data(:,1),'LineWidth',1);
legend('R_1 (initial)','R_2','R_3','Location','southeast')
xlabel('t [s]')
ylabel('u')
title('u for different weighting schemes (only R)')

%% -------- TASK 7 -------- %%
A_k=A;
B_k=B;
C_k=C_lin(2,:);
D_k=0;
sigma_Wd_1 = diag([1,10,1,10]);
sigma_Wd_2 = diag([10,1,10,1]);
sigma_Wd_3 = sigma_Wd_1;
sigma_Wn = 0.1;
sigma_Wn_3 = 1.5;
var = 0.0001;
mean = 0;
seed = 10000;
st = 0.001;
% Initial conditions
init_x0 = -0.01;
init_dx0 = 0.01;
init_phi0 = 0.05;
init_dphi0 = 0.1;

% Kalman filter
% 1
L_t7 = lqe(A_k,eye(4),C_k,sigma_Wd_1,sigma_Wn);
KF = ss(A_k-L_t7*C_k,[B_k L_t7],eye(4),0*[B_k L_t7]);
% 2
L_t7_2 = lqe(A_k,eye(4),C_k,sigma_Wd_2,sigma_Wn);
KF_2 = ss(A_k-L_t7_2*C_k,[B_k L_t7_2],eye(4),0*[B_k L_t7_2]);
% 3
L_t7_3 = lqe(A_k,eye(4),C_k,sigma_Wd_3,sigma_Wn_3); % sigma_Wd_3 = sigma_Wd_1;
KF_3 = ss(A_k-L_t7_3*C_k,[B_k L_t7_3],eye(4),0*[B_k L_t7_3]);
%% Plotting after simulation
figure; hold on; grid on;
plot(out.phi_t7,'LineWidth',1.5);
legend('\phi_{state}','\phi_{est}','Location','southeast')
xlabel('t [s]');
ylabel('\phi [rad]');
title('\sigma_{Wd,1} , \sigma_{Wn,1}')
% saveas(gcf, 'Task7_phi_var1.jpg');

figure; hold on; grid on;
plot(out.phi_t7_2,'LineWidth',1.5);
legend('\phi_{state}','\phi_{est}','Location','southeast')
xlabel('t [s]');
ylabel('\phi [rad]');
title('\sigma_{Wd,2} , \sigma_{Wn,1}')
% saveas(gcf, 'Task7_phi_var2.jpg');

figure; hold on; grid on;
plot(out.phi_t7_3,'LineWidth',1.5);
legend('\phi_{state}','\phi_{est}','Location','southeast')
xlabel('t [s]');
ylabel('\phi [rad]');
title('\sigma_{Wd,1} , \sigma_{Wn,3}')
% saveas(gcf, 'Task7_phi_var3.jpg');

figure; hold on; grid on;
plot(out.x_t7,'LineWidth',1.5);
legend('x_{state}','x_{est}','Location','southeast')
xlabel('t [s]');
ylabel('x [m]');
title('\sigma_{Wd,1} , \sigma_{Wn,1}')
% saveas(gcf, 'Task7_x_var1.jpg');

figure; hold on; grid on;
plot(out.x_t7_2,'LineWidth',1.5);
legend('x_{state}','x_{est}','Location','southeast')
xlabel('t [s]');
ylabel('x [m]');
title('\sigma_{Wd,2} , \sigma_{Wn,1}')
% saveas(gcf, 'Task7_x_var2.jpg');

figure; hold on; grid on;
plot(out.x_t7_3,'LineWidth',1.5);
legend('x_{state}','x_{est}','Location','southeast')
xlabel('t [s]');
ylabel('x [m]');
title('\sigma_{Wd,1} , \sigma_{Wn,3}')
% saveas(gcf, 'Task7_x_var3.jpg');

%% -------- TASK 8 -------- %%
N_mx=[A_k,B_k;C_k,0]^(-1)*[zeros(4,1);eye(1)];
Nx=N_mx(1:4);
sT=10;
%% Plotting after simulation
figure; hold on; grid on;
plot(out.input_path,'--','LineWidth',1.5);
%plot(out.actual_path,'LineWidth',1); % for comparison
plot(out.actual_path1,'LineWidth',1);
legend('Input path','Actual path using Q_4 weightning scheme')
xlabel('t [s]');
ylabel('x [m]');
hold off
% saveas(gcf, 'Task8.jpg');